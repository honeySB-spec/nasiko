from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Weather Integration Server")

@mcp.tool()
def fetch_weather(location: str) -> str:
    """Fetch the weather for a given query."""
    return f"Weather for {location} is 25°C and sunny."

if __name__ == "__main__":
    mcp.run(transport="stdio")
