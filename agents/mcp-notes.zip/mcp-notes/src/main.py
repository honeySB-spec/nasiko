from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Notes Storage Server")

@mcp.tool()
def save_note(title: str, content: str) -> str:
    """Save a note with a title and content."""
    return f"Note '{title}' saved successfully."

@mcp.tool()
def get_note(title: str) -> str:
    """Retrieve a note by its title."""
    return f"Content of note '{title}': This is a placeholder."

if __name__ == "__main__":
    mcp.run(transport="stdio")
