from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Calculator Integration Server")

@mcp.tool()
def calculate_sum(a: int, b: int) -> int:
    """Calculate the sum of two numbers."""
    return a + b

if __name__ == "__main__":
    mcp.run(transport="stdio")
